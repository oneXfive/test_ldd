#ifndef MEDIUM_H
#define MEDIUM_H

#include "../general.h"


extern int init_gpio();
extern int deinit_gpio();
extern int set_gpio_mode(gpio gpio_var,UINT8 mode);
extern int set_output_level(gpio gpio_var,UINT8 level);
extern int get_gpio_level(gpio gpio_var);

#endif // MEDIUM_H
