#ifndef GENERAL_H
#define GENERAL_H

#define SUCCESS 0
#define FAIL      1

typedef unsigned long long  UINT64;
typedef unsigned int        UINT32;
typedef unsigned short      UINT16;
typedef unsigned char       UINT8;

//BPI status code
typedef struct tag_gpio_struct
{
    int gpio_pin;
    int gpio_type;
}gpio;

#endif // GENERAL_H
