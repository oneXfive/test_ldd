#include "BPI.h"
//#include "general.h"
#include <sys/io.h>
#include <stdio.h>
#include <unistd.h>
#define OUTPUT 0
#define INPUT   1

#define LOW    0
#define HIGH    1

#define PCA9534 2
#define PCA9555 3

#define GPIO1 1
#define GPIO2 2
#define GPIO3 3
#define GPIO4 4
#define GPIO5 5
#define GPIO6 6
#define GPIO7 7
#define GPIO8 8
void use_nct6776()
{
	
}

void use_pca9534()
{
	int bResult;
	int ret_code = 0;

	int flag;
	int index;
	int mode;
	int level;

	int mode_index[8]={0};

		int  gpio1 = GPIO1;
		int  gpio2 = GPIO2;
		int  gpio3 = GPIO3;
		int  gpio4 = GPIO4;
		int  gpio5 = GPIO5;
		int  gpio6 = GPIO6;
		int  gpio7 = GPIO7;
		int  gpio8 = GPIO8;

		bResult = init_gpio();
		if (bResult == SUCCESS)
		{
			printf("init_gpio success.\n");
		} 
		else
		{
			printf("init_gpio fail.\n");
		}
		printf("\n");

		while(1)
		{
			printf("******************************\n");
			printf("1.set mode\n");
			printf("2.set level\n");
			printf("3.get level\n");
			printf("4.quit\n");
			printf("******************************\n");
			printf("please input number:\n");
			scanf("%d",&flag);

			if(flag==1)
			{
				printf("1.set mode:\n");
				printf("number of pin(1~8):\n");
				scanf("%d",&index);
				printf("set mode(0-output,1-input):\n");
				scanf("%d",&mode);

				mode_index[index] = mode;

				switch(index)
				{
				case 1:
					ret_code = set_gpio_mode(gpio1,mode);
					break;
				case 2:
					ret_code = set_gpio_mode(gpio2,mode);
					break;
				case 3:
					ret_code = set_gpio_mode(gpio3,mode);
					break;
				case 4:
					ret_code = set_gpio_mode(gpio4,mode);
					break;
				case 5:
					ret_code = set_gpio_mode(gpio5,mode);
					break;
				case 6:
					ret_code = set_gpio_mode(gpio6,mode);
					break;
				case 7:
					ret_code = set_gpio_mode(gpio7,mode);
					break;
				case 8:
					ret_code = set_gpio_mode(gpio8,mode);
					break;
				default:
					ret_code = FAILER;
					break;
				}
				if(ret_code== SUCCESS)
				{
					printf("set mode success!\n");					
				}
				else
				{
					printf("set mode fail!\n");
				}
				printf("\n");
			}
			else if(flag==2)
			{
				printf("2.set level:\n");
				printf("number of pin(1~8):\n");
				scanf("%d",&index);
				printf("set level(0-low,1-high):\n");
				scanf("%d",&level);

				if(mode_index[index]==1)
				{
					printf("pin[%d] is input mode\n",index);
				}
				else
				{
					switch(index)
					{
					case 1:
						ret_code = set_output_level(gpio1,level);
						break;
					case 2:
						ret_code = set_output_level(gpio2,level);
						break;
					case 3:
						ret_code = set_output_level(gpio3,level);
						break;
					case 4:
						ret_code = set_output_level(gpio4,level);
						break;
					case 5:
						ret_code = set_output_level(gpio5,level);
						break;
					case 6:
						ret_code = set_output_level(gpio6,level);
						break;
					case 7:
						ret_code = set_output_level(gpio7,level);
						break;
					case 8:
						ret_code = set_output_level(gpio8,level);
						break;
					default:
						ret_code = FAILER;
						break;
					}
					if(ret_code== SUCCESS)
					{
						printf("set level success!\n");					
					}
					else
					{
						printf("set level fail!\n");
					}
				}				
				printf("\n");
			}
			else if(flag==3)
			{
				printf("3.get level:\n");
				printf("number of pin(1~8):\n");
				scanf("%d",&index);

				switch(index)
				{
				case 1:
					ret_code = get_gpio_level(gpio1);
					printf("gpio1 level is %d.\n",ret_code);
					break;
				case 2:
					ret_code = get_gpio_level(gpio2);
					printf("gpio2 level is %d.\n",ret_code);
					break;
				case 3:
					ret_code = get_gpio_level(gpio3);
					printf("gpio3 level is %d.\n",ret_code);
					break;
				case 4:
					ret_code = get_gpio_level(gpio4);
					printf("gpio4 level is %d.\n",ret_code);
					break;
				case 5:
					ret_code = get_gpio_level(gpio5);
					printf("gpio5 level is %d.\n",ret_code);
					break;
				case 6:
					ret_code = get_gpio_level(gpio6);
					printf("gpio6 level is %d.\n",ret_code);
					break;
				case 7:
					ret_code = get_gpio_level(gpio7);
					printf("gpio7 level is %d.\n",ret_code);
					break;
				case 8:
					ret_code = get_gpio_level(gpio8);
					printf("gpio8 level is %d.\n",ret_code);
					break;
				default:
					printf("input number error!\n");
					break;
				}

				printf("\n");
			}
			else if(flag==4)
			{
				break;
			}
			else
			{
				printf("input number error!\n");
			}
		}

}

void use_pca9555()
{
	int bResult;
	int ret_code = 0;

	int flag;
	int index;
	int mode;
	int level;

	int mode_index[8]={0};

		int gpio1 = GPIO1;
		int gpio2 = GPIO2;
		int gpio3 = GPIO3;
		int gpio4 = GPIO4;
		int gpio5 = GPIO5;
		int gpio6 = GPIO6;
		int gpio7 = GPIO7;
		int gpio8 = GPIO8;

		bResult = init_gpio();
		if (bResult == SUCCESS)
		{
			printf("init_gpio success.\n");
		} 
		else
		{
			printf("init_gpio fail.\n");
			_exit(-1);
		}
		printf("\n");

		while(1)
		{
			printf("******************************\n");
			printf("1.set mode\n");
			printf("2.set level\n");
			printf("3.get level\n");
			printf("4.quit\n");
			printf("******************************\n");
			printf("please input number:\n");
			scanf("%d",&flag);

			if(flag==1)
			{
				printf("1.set mode:\n");
				printf("number of pin(1~8):\n");
				scanf("%d",&index);
				printf("set mode(0-output,1-input):\n");
				scanf("%d",&mode);

				mode_index[index] = mode;

				switch(index)
				{
				case 1:
					ret_code = set_gpio_mode(gpio1,mode);
					break;
				case 2:
					ret_code = set_gpio_mode(gpio2,mode);
					break;
				case 3:
					ret_code = set_gpio_mode(gpio3,mode);
					break;
				case 4:
					ret_code = set_gpio_mode(gpio4,mode);
					break;
				case 5:
					ret_code = set_gpio_mode(gpio5,mode);
					break;
				case 6:
					ret_code = set_gpio_mode(gpio6,mode);
					break;
				case 7:
					ret_code = set_gpio_mode(gpio7,mode);
					break;
				case 8:
					ret_code = set_gpio_mode(gpio8,mode);
					break;
				default:
					ret_code = FAILER;
					break;
				}
				if(ret_code== SUCCESS)
				{
					printf("set mode success!\n");					
				}
				else
				{
					printf("set mode fail!\n");
				}
				printf("\n");
			}
			else if(flag==2)
			{
				printf("2.set level:\n");
				printf("number of pin(1~8):\n");
				scanf("%d",&index);
				printf("set level(0-low,1-high):\n");
				scanf("%d",&level);

				if(mode_index[index]==1)
				{
					printf("pin[%d] is input mode\n",index);
				}
				else
				{
					switch(index)
					{
					case 1:
						ret_code = set_output_level(gpio1,level);
						break;
					case 2:
						ret_code = set_output_level(gpio2,level);
						break;
					case 3:
						ret_code = set_output_level(gpio3,level);
						break;
					case 4:
						ret_code = set_output_level(gpio4,level);
						break;
					case 5:
						ret_code = set_output_level(gpio5,level);
						break;
					case 6:
						ret_code = set_output_level(gpio6,level);
						break;
					case 7:
						ret_code = set_output_level(gpio7,level);
						break;
					case 8:
						ret_code = set_output_level(gpio8,level);
						break;
					default:
						ret_code = FAILER;
						break;
					}
					if(ret_code== SUCCESS)
					{
						printf("set level success!\n");					
					}
					else
					{
						printf("set level fail!\n");
					}
				}				
				printf("\n");
			}
			else if(flag==3)
			{
				printf("3.get level:\n");
				printf("number of pin(1~8):\n");
				scanf("%d",&index);

				switch(index)
				{
				case 1:
					ret_code = get_gpio_level(gpio1);
					printf("gpio1 level is %d.\n",ret_code);
					break;
				case 2:
					ret_code = get_gpio_level(gpio2);
					printf("gpio2 level is %d.\n",ret_code);
					break;
				case 3:
					ret_code = get_gpio_level(gpio3);
					printf("gpio3 level is %d.\n",ret_code);
					break;
				case 4:
					ret_code = get_gpio_level(gpio4);
					printf("gpio4 level is %d.\n",ret_code);
					break;
				case 5:
					ret_code = get_gpio_level(gpio5);
					printf("gpio5 level is %d.\n",ret_code);
					break;
				case 6:
					ret_code = get_gpio_level(gpio6);
					printf("gpio6 level is %d.\n",ret_code);
					break;
				case 7:
					ret_code = get_gpio_level(gpio7);
					printf("gpio7 level is %d.\n",ret_code);
					break;
				case 8:
					ret_code = get_gpio_level(gpio8);
					printf("gpio8 level is %d.\n",ret_code);
					break;
				default:
					printf("input number error!\n");
					break;
				}

				printf("\n");
			}
			else if(flag==4)
			{
				break;
			}
			else
			{
				printf("input number error!\n");
			}
		}

}

int main()
{
    iopl(3);//must add

    int bResult;
    int level = 0;
    int ret_code = 0;
    int flag;
	init_watchdog();
	start_watchdog(5,0);
     int i=0;
	while(i<5)
	{
		feed_watchdog(5);
		flag = get_watchdog_current_timeout_value();
		printf("timeout is %d\n",flag);
		sleep(1);
		i++;
	}
	while(1)
	{
			
		flag = get_watchdog_current_timeout_value();
		printf("timeout is %d\n",flag);
		sleep(1);
	}
//
//use_pca9534();
//	init_gpio();
    /*printf("******************************\n");
    printf("1.pca9555\n");
    printf("2.pca9534\n");
	printf("3.nct6776\n");
	printf("4.nct6106d\n");
    printf("******************************\n");
    printf("please input number:\n");
    scanf("%d",&flag);
    
    if(flag == 1)
    {
		use_pca9555();
    }
    else if(flag == 2)
    {
		use_pca9534();
    }*/

	
    iopl(0);//must add

    return 0;
}
