#ifndef MEDIUM_H
#define MEDIUM_H

#include "general.h"


extern int init_gpio();
extern int set_gpio_mode(int pin,UINT8 mode);
extern int set_output_level(int pin,UINT8 level);
extern int get_gpio_level(int pin);
extern int init_watchdog();
extern int start_watchdog(UINT8 timeout,UINT8 watchdog_mode);
extern int feed_watchdog(UINT8 timeout);
extern int stop_watchdog();
extern int get_watchdog_current_timeout_value();
#endif // MEDIUM_H
