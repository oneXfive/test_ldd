#include "stdafx.h"
#include <windows.h>
#include <stdio.h>
#include "BPI.h"


#define OUTPUT 0
#define INPUT   1

#define LOW    0
#define HIGH    1

#define gpio1 1
#define gpio2 2
#define gpio3 3
#define gpio4 4
#define gpio5 5
#define gpio6 6
#define gpio7 7
#define gpio8 8

#pragma comment(lib,"BPI.lib")


void use_gpio()
{
	int bResult;
	int ret_code = 0;

	int flag;
	int index;
	int mode;
	int level;

	int mode_index[8]={0};

	bResult = init_gpio();
	if (bResult == SUCCESS)
		{
			printf("init_gpio success.\n");
		} 
	else
		{
			printf("init_gpio fail.\n");
			return ;
		}
	printf("\n");

	while(1)
		{
			printf("******************************\n");
			printf("1.set mode\n");
			printf("2.set level\n");
			printf("3.get level\n");
			printf("4.quit\n");
			printf("******************************\n");
			printf("please input number:\n");
			scanf("%d",&flag);

			if(flag==1)
			{
				printf("1.set mode:\n");
				printf("number of pin(1~8):\n");
				scanf("%d",&index);
				printf("set mode(0-output,1-input):\n");
				scanf("%d",&mode);

				mode_index[index] = mode;

				switch(index)
				{
				case 1:
					ret_code = set_gpio_mode(gpio1,mode);
					break;
				case 2:
					ret_code = set_gpio_mode(gpio2,mode);
					break;
				case 3:
					ret_code = set_gpio_mode(gpio3,mode);
					break;
				case 4:
					ret_code = set_gpio_mode(gpio4,mode);
					break;
				case 5:
					ret_code = set_gpio_mode(gpio5,mode);
					break;
				case 6:
					ret_code = set_gpio_mode(gpio6,mode);
					break;
				case 7:
					ret_code = set_gpio_mode(gpio7,mode);
					break;
				case 8:
					ret_code = set_gpio_mode(gpio8,mode);
					break;
				default:
					ret_code = FAIL;
					break;
				}
				if(ret_code== SUCCESS)
				{
					printf("set mode success!\n");					
				}
				else
				{
					printf("set mode fail!\n");
				}
				printf("\n");
			}
			else if(flag==2)
			{
				printf("2.set level:\n");
				printf("number of pin(1~8):\n");
				scanf("%d",&index);
				printf("set level(0-low,1-high):\n");
				scanf("%d",&level);

				if(mode_index[index]==1)
				{
					printf("pin[%d] is input mode\n",index);
				}
				else
				{
					switch(index)
					{
					case 1:
						ret_code = set_output_level(gpio1,level);
						break;
					case 2:
						ret_code = set_output_level(gpio2,level);
						break;
					case 3:
						ret_code = set_output_level(gpio3,level);
						break;
					case 4:
						ret_code = set_output_level(gpio4,level);
						break;
					case 5:
						ret_code = set_output_level(gpio5,level);
						break;
					case 6:
						ret_code = set_output_level(gpio6,level);
						break;
					case 7:
						ret_code = set_output_level(gpio7,level);
						break;
					case 8:
						ret_code = set_output_level(gpio8,level);
						break;
					default:
						ret_code = FAIL;
						break;
					}
					if(ret_code== SUCCESS)
					{
						printf("set level success!\n");					
					}
					else
					{
						printf("set level fail!\n");
					}
				}				
				printf("\n");
			}
			else if(flag==3)
			{
				printf("3.get level:\n");
				printf("number of pin(1~8):\n");
				scanf("%d",&index);

				switch(index)
				{
				case 1:
					ret_code = get_gpio_level(gpio1);
					printf("gpio1 level is %d.\n",ret_code);
					break;
				case 2:
					ret_code = get_gpio_level(gpio2);
					printf("gpio2 level is %d.\n",ret_code);
					break;
				case 3:
					ret_code = get_gpio_level(gpio3);
					printf("gpio3 level is %d.\n",ret_code);
					break;
				case 4:
					ret_code = get_gpio_level(gpio4);
					printf("gpio4 level is %d.\n",ret_code);
					break;
				case 5:
					ret_code = get_gpio_level(gpio5);
					printf("gpio5 level is %d.\n",ret_code);
					break;
				case 6:
					ret_code = get_gpio_level(gpio6);
					printf("gpio6 level is %d.\n",ret_code);
					break;
				case 7:
					ret_code = get_gpio_level(gpio7);
					printf("gpio7 level is %d.\n",ret_code);
					break;
				case 8:
					ret_code = get_gpio_level(gpio8);
					printf("gpio8 level is %d.\n",ret_code);
					break;
				default:
					printf("input number error!\n");
					break;
				}

				printf("\n");
			}
			else if(flag==4)
			{
				break;
			}
			else
			{
				printf("input number error!\n");
			}
		}

}




void use_watchdog()
{
	int mode=0;
	int choice=0;
	int timeout=10;
	int feedtime=(int)0.6*timeout;

	while(1)
	{
		printf("1.Set TimeOut Value\n"
			   "2.Set FeedTime Value\n"
			   "3.Set Countdown Mode\n"
			   "4.Set As Default\n"
			   "5.Start WatchGog\n"
			   "6.Feed WatchDog\n"
			   "7.Stop WatchDog\n"
			   "8.Auto Test\n"
			   "9.Quit\n");
		printf("Please make a choice:\n");
		scanf("%d",&choice);
		if(choice == 9)
		{
			break;
		}
		switch(choice)
		{
			case 1:
				printf("Please input a int value:\n");
				scanf("%d",&timeout);
				break;
			case 2:
				printf("Please input a int value between 0.3*timeout to 0.6*timeout:\n");
				scanf("%d",&feedtime);
				break;
			case 3:
				printf("0: second mode\n"
					   "1: minute mode\n");
				scanf("%d",&mode);
				break;
			case 4:
				break;
			case 5:
				init_watchdog();
				start_watchdog(timeout,mode);
				feed_watchdog(timeout);
				break;
			case 6:
				feed_watchdog(timeout);
			case 7:
				stop_watchdog();
			case 8:
				{
					init_watchdog();
					start_watchdog(timeout,mode);
					int i = 0;
					int flag;
					while(i<5)
					{
						
						flag = get_watchdog_current_timeout_value();
						printf("timeout is %d\n",flag);
						Sleep(feedtime);
						i++;
					}
					printf("Stop FeedDog,Computer Will reboot in:");
					while(1)
					{
							
						flag = get_watchdog_current_timeout_value();
						printf("timeout is %d\n",flag);
						Sleep(1000);
					}
				}
				break;
			default:
				break;
		}
		
	}

}

int main()
{


    int bResult;
    int level = 1;
    int ret_code = 0;
    int flag;



	while(1)
	{

		printf("******************************\n");
		printf("1.TEST GPIO\n");
		printf("2.TEST WATCHDOG\n");
		printf("3.QUIT\n");
		/*printf("3.nct6776\n");
		printf("4.nct6106d\n");*/
		printf("******************************\n");
		printf("please input number:\n");
		scanf("%d",&flag);
    
		if(flag == 1)
		{
			use_gpio();
		}
		else if(flag == 2)
		{
			use_watchdog();
		}
		else if(flag == 3)
		{
			return 0;

		}

		getchar();
	}

    return 0;
}
