/*
#**************************************************************************
#*                                                                        *
#*      EVOC BPI                                                          *
#*                                                                        *
#*      EVOC BPI Reference Code                                           *
#*                                                                        *
#*      Copyright (c) 2011 EVOC  Corp.                                    *
#*                                                                        *
#*      BPI Reference Code                                                *
#*      Version	A00                                                       *
#*			Build Tool:VS2008											  *
#*      Date    2018-11-16                                                *
#*                                                                        *
#*      This program has been developed by EVOC software department       *
#*. This source code may NOT be redistributed to anyone without           *
#*      EVOC's written permission.                                        *
#*                                                                        *
#**************************************************************************

#**************************************************************************
*	�°�BPI���ע������:                                                  *
*   1���°汾BPI�ǽ�����֮ǰ��BPI2.0/BPI3.0/BPI3.1�Ļ���֮�ϵģ�          *
*   2��Windows/Linux�Ĵ�����ѭͳһ�Ĵ���淶                              *
*   3��Windows/Linux��оƬ��Ķ�̬��Ĵ���80%����ͬ�ģ���������������ͬ�� *
*   Windows����winio3.0��GetPortVal/SetPortVal�ȷ�����صĶ˿ڣ���Linux�� *
*   ����inb/outb,inw/outw,inl/outl�ȷ�����صĶ˿�                        *
*   4���°汾��BPIҪ�����32bit/64bit��̬�����Ӧ�ľ�̬��                 *
#**************************************************************************
*/

/**************************************************************************
*  nct6776.h                                                                 *
*  Copyright (c) 2011 EVOC  Corp. 
*  Author   sz.czxu@evoc.cn
*  Version   A00                                                          *
*  Build Tool: Windows vs2008                                             *
*              Linux  vim and makefile                                    *
* ��;��superio 61606d��ض���                                                  *
* ���ã�Windows/Linux�����г���Ҫ����                                   *
#**************************************************************************
*/

#ifndef __NCT6776_H
#define __NCT6776_H


#define GPIO0_GROUP_LOGIC_REG 0x08
#define GPIO1_GROUP_LOGIC_REG 0x08
#define GPIO2_GROUP_LOGIC_REG 0x09
#define GPIO3_GROUP_LOGIC_REG 0x09
#define GPIO4_GROUP_LOGIC_REG 0x09
#define GPIO5_GROUP_LOGIC_REG 0x09

#define GPIO6_GROUP_LOGIC_REG 0x07
#define GPIO7_GROUP_LOGIC_REG 0x07
#define GPIO8_GROUP_LOGIC_REG 0x07
#define GPIO9_GROUP_LOGIC_REG 0x07
#define GPIOA_GROUP_LOGIC_REG 0x07



#define GPIO0_GROUP_OD_REG    0x0F
#define GPIO1_GROUP_OD_REG    0x0F
#define GPIO2_GROUP_OD_REG    0x0F
#define GPIO3_GROUP_OD_REG    0x0F

#define GPIO4_GROUP_OD_REG    0x0F
#define GPIO5_GROUP_OD_REG    0x0F
#define GPIO6_GROUP_OD_REG    0x0F
#define GPIO7_GROUP_OD_REG    0x0F
#define GPIO8_GROUP_OD_REG    0x0F
#define GPIO9_GROUP_OD_REG    0x0F
#define GPIOA_GROUP_OD_REG    0x0F


_declspec(dllexport) int nct6776_init_gpio(int index_port,int data_port);

_declspec(dllexport) int nct6776_set_gpio_mode(int gpio_pin, int mode);

_declspec(dllexport) int nct6776_set_output_level(int gpio_pin, int pin_level);

_declspec(dllexport) int nct6776_get_gpio_level(int gpio_pin);

_declspec(dllexport) int nct6776_get_gpio_mode(int gpio_pin);

_declspec(dllexport) int nct6776_init_watchdog(int AddrPort,int DataPort);

_declspec(dllexport) int nct6776_start_watchdog(UINT8 timeout,UINT8 watchdog_mode);

_declspec(dllexport) int nct6776_feed_watchdog(UINT8 timeout);

_declspec(dllexport) int nct6776_stop_watchdog();

#endif
